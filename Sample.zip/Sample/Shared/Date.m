//
//  Date.m
//  Sample
//
//  Created by Rebecca Har on 10/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Date.h"


@implementation Date

//Put the date specified by the three arguments into the newborn Date object.

- (id) initWithMonth: (int) m day: (int) d year: (int) y {
	//Send the init message to the superclass object in myself.
	self = [super init];
	if (self != nil) {
		year = y;
		month = m;
		day = d;
	}
	
	return self;
}

//Put today's date into the newborn Date object.

- (id) init {
	self = [super init];
	if (self != nil) {
		NSCalendar *g = [[NSCalendar alloc]
						 initWithCalendarIdentifier: NSGregorianCalendar];
		
		NSDate *today = [[NSDate alloc] init];
		
		NSUInteger unitFlags =
		NSYearCalendarUnit
		| NSMonthCalendarUnit
		| NSDayCalendarUnit;
		
		NSDateComponents *c = [g components: unitFlags fromDate: today];
		
		year  = [c year];
		month = [c month];
		day   = [c day];
		
		[today release];
		[g release];
	}
	
	return self;
}

//Return the number of days in the month instance variable (1 to 31 inclusive).

- (int) monthLength {
	
	NSCalendar *g = [[NSCalendar alloc]
					 initWithCalendarIdentifier: NSGregorianCalendar];
	
	NSDateComponents *c = [[NSDateComponents alloc] init];
	[c setYear: year];
	[c setMonth: month];
	[c setDay: day];
	
	NSRange r = [g			//r is a structure, not an object
				 rangeOfUnit: NSDayCalendarUnit
				 inUnit: NSMonthCalendarUnit
				 forDate: [g dateFromComponents: c]
				 ];
	
	[c release];
	[g release];
	return r.length;
}

- (NSString *) description {
	return [NSString stringWithFormat: @"%d/%d/%d", month, day, year];
}

- (int) year {
	return year;
}

- (int) month {
	return month;
}

- (int) day {
	return day;
}

- (void) setYear: (int) y {
	year = y;
}

- (void) setMonth: (int) m {
	if (m < 1 || m > 12) {	//|| means "(non-bitwise) or"
		NSLog(@"setMonth: bad month %d", m);
		return;
	}
	
	month = m;
}

- (void) setDay: (int) d {
	if (d < 1 || d > [self monthLength]) {
		NSLog(@"setDay: bad day %d with month %d", d, month);
		return;
	}
	
	day = d;
}

//Return YES if this Date is equal to the other Date, NO otherwise.

- (BOOL) isEqual: (Date *) another {
	return year == another.year
	&& month == another.month	//&& means "(non-bitwise) and"
	&& day == another.day;
}

//Advance the Date one day into the future.
//This method accepts no arguments.

- (void) next {
	if (day < [self monthLength]) {
		++day;
		return;
	}
	
	day = 1;
	if (month < 12) {
		++month;
		return;
	}
	
	month = 1;
	++year;
}

/*
 Advance the Date many days into the future.
 This method accepts one argument.
 It does the bulk of its work by calling the above method over and over.
 */

- (void) next: (int) distance {
	if (distance < 0) {
		NSLog(@"argument %d of next: must be non-negative", distance);
		return;
	}
	
	for (int i = 1; i <= distance; ++i) {
		[self next];
	}
}

// Return the number of months in a year.  A class method is marked with a plus.

+ (int) yearLength {
	return 12;
}

- (void) dealloc {
	[super dealloc];
}
@end
