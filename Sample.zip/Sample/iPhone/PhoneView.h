//
//  PhoneView.h
//  Sample
//
//  Created by Rebecca Har on 10/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface PhoneView : UIView {

}

@end
