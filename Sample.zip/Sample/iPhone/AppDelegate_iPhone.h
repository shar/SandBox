//
//  AppDelegate_iPhone.h
//  Sample
//
//  Created by Rebecca Har on 10/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

// included all the classes needed for the Delegate
@class PhoneView;

@interface AppDelegate_iPhone : NSObject <UIApplicationDelegate> {
    PhoneView *phoneview;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

