//
//  PadView.m
//  Sample
//
//  Created by Rebecca Har on 10/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PadView.h"


@implementation PadView


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
	if (self) {
        // Initialization code.
		self.backgroundColor = [UIColor colorWithRed:0.2 green:0.4 blue:0.2 alpha:1.0];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
	UIFont *f = [UIFont systemFontOfSize: 32.0];
 
	NSString *s = @"First ipad apps";
	CGPoint p = CGPointMake(0.0, 0.0);
	[s drawAtPoint: p withFont: f];
}


- (void)dealloc {
    [super dealloc];
}


@end
