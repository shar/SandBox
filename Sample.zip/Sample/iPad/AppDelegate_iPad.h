//
//  AppDelegate_iPad.h
//  Sample
//
//  Created by Rebecca Har on 10/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

// included all the classes needed for the Delegate
@class PadView;

@interface AppDelegate_iPad : NSObject <UIApplicationDelegate> {
	PadView *padview;
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

